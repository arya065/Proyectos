<?php
// define("DIR_SERV", "http://proyectos/API/ej2/login_restful");
define("DIR_SERV", "http://localhost/Proyectos/examen_4/Examen4_SW_23_24/Examen4_SW/servicios_rest");
define("USER", "jose");
define("PASS", "josefa");
define("DB_NAME", "bd_exam_colegio2");
